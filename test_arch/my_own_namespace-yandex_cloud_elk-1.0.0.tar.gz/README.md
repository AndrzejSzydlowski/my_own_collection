# Ansible Collection - my_own_namespace.yandex_cloud_elk

Its run role Module test which take path and content from /default/main.yml
with tasks from /tasks/main.yml which run module test_module.py
Thats one create a directory with file path/'myfile.txt' with content.
